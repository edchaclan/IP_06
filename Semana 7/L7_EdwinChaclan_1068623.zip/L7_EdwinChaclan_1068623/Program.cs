﻿
namespace Lab7
{
    class program
    {
        static void Main(string[] args)
        {
            // Ejercicio 1
            Console.WriteLine("Ejercicio Número 1");
            int num1 = 0;
            Console.WriteLine("Escoja un número para comprobar si es negativo, positivo o cero");
            num1  = Int32.Parse(Console.ReadLine());
            
            if (num1 == 0)
            {
                Console.WriteLine("El número elegido es 0");
            }
            else if (num1 < 0)
            {
                Console.WriteLine("El número elegido es negativo");
            }
            else if (num1 > 0) {
                Console.WriteLine("El número es positivo");
            }
           
            Console.ReadKey();
            Console.Clear();

            //Ejercicio 2
            Console.WriteLine("Ejercicio Número 2");
            int opcion = 0;
            Console.WriteLine("Ingresar opción a elegir de los días de las semana, Lunes=1....");
            opcion = Int32.Parse(Console.ReadLine());
            switch (opcion)
            {
                case 1:
                    Console.WriteLine("Día Lunes");
                    break;
                case 2:
                    Console.WriteLine("´Día Martes");
                    break;

                case 3:
                    Console.WriteLine("´Día Miércoles");
                    break;
                case 4:
                    Console.WriteLine("´Día Jueves");
                    break;
                case 5:
                    Console.WriteLine("´Día Viernes");
                    break;
                case 6:
                    Console.WriteLine("´Día Sábado");
                    break;
                case 7:
                    Console.WriteLine("´Día Domingo");
                    break;

                default:
                    break;
            }
        }
    }
}
﻿using System;

class Program
{
    static void Main(string[]args)
    { 
    Console.WriteLine("Bienvenido al programa de MRUV en el cual podrás calcular Velocidad Final, Inicial , aceleración y tiempo, con tener 3 variables");
double vo, vf, a, t;
    Console.WriteLine("Ingrese tres de las variables que posee, para calcular la restante, en la variable que desee calcular ingresar 0");
Console.WriteLine("Ingrese el valor de la Velocidad inicial, si es el que desea encontrar ingrese 0");
vo = Convert.ToDouble(Console.ReadLine());
Console.WriteLine("Ingrese el valor de la Velocidad final, si es el que desea encontrar ingrese 0");
vf = Convert.ToDouble(Console.ReadLine());
Console.WriteLine("Ingrese el valor de la aceleración, si es el que desea encontrar ingrese 0");
a = Convert.ToDouble(Console.ReadLine());
Console.WriteLine("Ingrese el valor del tiempo, si es el que desea encontrar ingrese 0");
t = Convert.ToDouble(Console.ReadLine());
   double velocidadinicial = vf - (a*t);
   double velocidadfinal = vo + (a*t);

   double tiempo = (vf - vo) / a;
        if (vo == 0)
            {
                Console.WriteLine("La velocidad inicial de la partícula es: " + "" + velocidadinicial + " m/s");
            }
        else if (vf == 0)
            {
                Console.WriteLine("la velocidad final de la partícula es: " + "" + velocidadfinal + " m/s");
            }
        else if (a == 0)
            {
            double aceleracion = (vf - vo) / t;
            Console.WriteLine("La aceleración de la partícula es de: " + "" + aceleracion + " m/s2");
            }
        else if (t == 0) {
            Console.WriteLine("El tiempo que tarda la partícula es de: " + "" + tiempo + " s");
            }
         else
            {
            Console.WriteLine("Vuelva a ingresar los datos, recuerde que el que desea encontrar debe de ser 0");
            }
        Console.ReadKey();
    }
}
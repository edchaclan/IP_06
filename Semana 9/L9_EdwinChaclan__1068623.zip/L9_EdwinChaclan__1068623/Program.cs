﻿
class Program
{
    public static void Main()
    {
        Console.WriteLine("Bienvenido a tiendita la bendición");
        double monto = Monto();
        string codigoDescuento = Codigodedescuento();
        AplicarDescuento(monto, codigoDescuento);
    }

    public static double Monto()
    {
        double monto;
        while (true)
        {
            Console.WriteLine("Ingresar el monto a pagar:");

            if (double.TryParse(Console.ReadLine(), out monto))
            {
                break;
            }
            else
            {
                Console.WriteLine("Ingresar formato válido en número");
            }
        }
        return monto;
    }
    public static string Codigodedescuento()
    {
        Console.WriteLine("¿Código de descuento? Si o no ");
        return Console.ReadLine().Trim();   /*trim sirve para eliminar espacios en blanco, sirve para booleanos y eliminar rango de error de escritura*/
    }
    public static void AplicarDescuento(double monto, string codigoDescuento)
    {
        double montoConDescuento = CalcularDescuento(monto);
        if (tienedescuento(codigoDescuento))
        {
            if (string.Equals(codigoDescuento, "Si", StringComparison.OrdinalIgnoreCase))
            {
                montoConDescuento *= 0.95; 
            }
        }
        Montoapagar(montoConDescuento);
    }

    public static double CalcularDescuento(double monto)
    {
        if (monto < 400)
        { }
        else
        {
            if (monto <= 1000)      /*No necesita mayor y menor que ya que si es menor que 400 detecta el primer if*/
            {
                monto *= 0.93; 
            }
            else
            {
                if (monto <= 5000)
                {
                    monto *= 0.90; 
                }
                else
                {
                    if (monto <= 15000)
                    {
                        monto *= 0.85; 
                    }
                    else
                    {
                        monto *= 0.75; 
                    }
                }
            }
        }

        return monto;           //regresa el valor con el descuento aplicado :)
    }

    public static bool tienedescuento(string respuesta)
    {
        return string.Equals(respuesta, "Si", StringComparison.OrdinalIgnoreCase) ^
               string.Equals(respuesta, "No", StringComparison.OrdinalIgnoreCase);
    }
    public static void Montoapagar(double monto)
    {
        Console.WriteLine($"El monto que debe de pagar en tiendita la bendición es de : {monto} quetzales");
        Console.ReadKey();
    }
}
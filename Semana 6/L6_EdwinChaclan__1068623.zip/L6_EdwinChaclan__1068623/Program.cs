﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ConsoleApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            //Ejercicio 1
            Console.WriteLine("Ejercicio 1: Operaciones aritméticas");
            int num1 = 0;
            int num2 = 0;
            Console.WriteLine("Ingrese el primer número");
            num1 = Int32.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese el segundo número");
            num2 = Int32.Parse(Console.ReadLine());
            int suma = num1 + num2;
            int resta = num1 - num2;
            int multiplicacion = num1 * num2;

            Console.WriteLine("El número " + "" + num1 + " sumado por " + "" + num2 + "" + " es igual a " + "" + suma);
            Console.WriteLine("El número " + "" + num1 + " restado  por " + "" + num2 + "" + " es igual a " + "" + resta);
            Console.WriteLine("El número " + "" + num1 + " multiplicado  por " + "" + num2 + "" + " es igual a " + "" + multiplicacion);
            int div = num1 / num2;
            int mod = num1 % num2;
            Console.WriteLine("El número " + "" + num1 + " residuo  por " + "" + num2 + "" + " es igual a " + "" + mod);
            Console.WriteLine("El número " + "" + num1 + " dividido  por " + "" + num2 + "" + " es igual a " + "" + div);



            Console.ReadKey();
            Console.Clear();
            // Ejercicio 2
            Console.WriteLine("Ejercicio 2: Operaciones booleanas");
            bool mayorque = num1 > num2;
            bool menorque = num1 < num2;
            bool igual = num1 == num2;
            Console.WriteLine(num1 + " > " + num2 + " = " + mayorque );
            Console.WriteLine(num1 + " < " + num2 + " = " + menorque);
            Console.WriteLine(num1 + " = " + num2 + " = " + igual);

            //Ejercicio 3
            Console.WriteLine("Ejercicio 3: Jerarquía de operaciones");
          double a, b, c;
            Console.WriteLine("Ingrese el valor de a: ");
            a = Int32.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese el valor de b: ");
            b = Int32.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese el valor de c: ");
            c = Int32.Parse(Console.ReadLine());

            double i = a * b + c;
           double ii = a*(b + c);
            double iii = a / b * c;
            double iv = (3 * a + 2 * b) / c*c;

            Console.WriteLine("Resultado primer operacion: " + i);
            Console.WriteLine("Resultado segunda operacion: " + ii);
            Console.WriteLine("Resultado tercer operacion: " + iii);
            Console.WriteLine("Resultado cuarta operacion: " + iv);
            Console.ReadKey();
            Console.Clear();

            //Ejercicio 4
            Console.WriteLine("Ecuación cuadrática");
          
            double determ= (b* b) - 4 * ( a * c);

            if (determ >= 0 && a != 0)
            { double Respuesta1 = (-b + Math.Sqrt(determ)) / (2 * a);
              double respuesta2 = (-b - Math.Sqrt(determ)) / (2 * a);
              Console.Write("Soluciones ecuacion: " + Respuesta1 + " y  " + respuesta2);
            }
            
            else
            {
                Console.WriteLine("La ecuación posee solución imaginaria :,v");
            }
             
        }


    }
}